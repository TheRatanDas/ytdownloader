# yt-dler
A simple YouTube video downloader. Still a work-in-progress project to this day, even though I don't really want to finish it anyway 🤷

### Badges 
[![Build Status](https://travis-ci.com/mazzlabs/yt-dler.svg?token=Cr4qTHeGpqFut83csnvB&branch=master)](https://travis-ci.com/mazzlabs/yt-dler)
![Node.js CI](https://github.com/Ma15fo43/Electron-YouTube-Downloader/workflows/Node.js%20CI/badge.svg)
[![Depfu](https://badges.depfu.com/badges/dc190be134fe4e94bcebca9c492ae679/overview.svg)](https://depfu.com/github/mazzlabs/Electron-YouTube-Downloader?project_id=17264)
